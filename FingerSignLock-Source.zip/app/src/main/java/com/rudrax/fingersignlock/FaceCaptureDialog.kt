package com.rudrax.fingersignlock

import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import java.util.Locale
import java.util.concurrent.Executors

/** Full-screen camera dialog used to enroll the owner's face, or to test the match live. */
class FaceCaptureDialog(
    private val activity: AppCompatActivity,
    private val testMode: Boolean,
    private val accent: Int,
    private val threshold: Float,
    private val onFinished: (saved: Boolean) -> Unit
) {
    private val dialog = Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
    private val executor = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private var landmarker: FaceLandmarker? = null
    private val samples = mutableListOf<FloatArray>()
    private var lastSampleAt = 0L
    @Volatile private var closed = false
    @Volatile private var saved = false

    private lateinit var guide: GuideView
    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var score: TextView
    private lateinit var button: TextView

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density + 0.5f).toInt()

    private class GuideView(context: Context, private val accent: Int) : View(context) {
        var progress = 0f
        var ringColor = accent
        private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC000000.toInt() }
        private val base = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = 0x55FFFFFF; strokeWidth = 8f
        }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 14f; strokeCap = Paint.Cap.ROUND
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val ow = w * 0.72f; val oh = ow * 1.30f
            val rect = RectF((w - ow) / 2f, h * 0.42f - oh / 2f, (w + ow) / 2f, h * 0.42f + oh / 2f)
            val path = Path().apply {
                addOval(rect, Path.Direction.CW); fillType = Path.FillType.INVERSE_EVEN_ODD
            }
            canvas.drawPath(path, dim)
            canvas.drawOval(rect, base)
            arc.color = ringColor
            val sweep = if (progress >= 1f) 360f else 360f * progress
            if (sweep > 0f) canvas.drawArc(rect, -90f, sweep, false, arc)
        }
    }

    fun show() {
        val root = FrameLayout(activity).apply { setBackgroundColor(Color.BLACK) }
        val preview = PreviewView(activity).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        root.addView(preview, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        guide = GuideView(activity, accent)
        root.addView(guide, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        title = TextView(activity).apply {
            text = if (testMode) "Test face match" else "Set up your face"
            textSize = 22f; setTextColor(Color.WHITE); setTypeface(Typeface.DEFAULT, Typeface.BOLD); gravity = Gravity.CENTER
        }
        root.addView(title, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply {
            topMargin = dp(48); marginStart = dp(24); marginEnd = dp(24)
        })

        val bottom = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        status = TextView(activity).apply {
            text = if (testMode) "Look straight at the camera" else "Fit your face inside the oval and look straight at the camera"
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        score = TextView(activity).apply {
            textSize = 13f; setTextColor(0xFFCCCCCC.toInt()); gravity = Gravity.CENTER
            if (!testMode) visibility = View.GONE
        }
        button = TextView(activity).apply {
            text = if (testMode) "Done" else "Cancel"
            textSize = 15f; setTextColor(Color.WHITE); setTypeface(Typeface.DEFAULT, Typeface.BOLD); gravity = Gravity.CENTER
            setPadding(dp(32), dp(14), dp(32), dp(14))
            background = GradientDrawable().apply { setColor(0x33FFFFFF); cornerRadius = dp(16).toFloat(); setStroke(dp(1), 0x66FFFFFF) }
            isClickable = true
            setOnClickListener { dialog.dismiss() }
        }
        bottom.addView(status)
        bottom.addView(score, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        bottom.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(18) })
        root.addView(bottom, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            bottomMargin = dp(48); marginStart = dp(24); marginEnd = dp(24)
        })

        dialog.setContentView(root)
        dialog.setCancelable(true)
        dialog.setOnDismissListener {
            stopCamera()
            onFinished(saved)
        }
        dialog.show()
        startCamera(preview)
    }

    private fun startCamera(preview: PreviewView) {
        val future = ProcessCameraProvider.getInstance(activity)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor) { image ->
                    try {
                        if (!closed) {
                            val bmp = FaceEngine.rotate(image.toBitmap(), image.imageInfo.rotationDegrees)
                            val lm = landmarker ?: FaceEngine.createLandmarker(activity).also { landmarker = it }
                            val res = lm.detect(BitmapImageBuilder(bmp).build())
                            val face = res.faceLandmarks().firstOrNull()
                            val sig = face?.let { FaceEngine.signature(it, bmp.width, bmp.height) }
                            onFrame(face != null, sig)
                        }
                    } catch (e: Exception) {
                        ui { status.text = "Face model error. Rebuild the app so face_landmarker.task is included." }
                    } finally {
                        image.close()
                    }
                }
                p.unbindAll()
                p.bindToLifecycle(activity, CameraSelector.DEFAULT_FRONT_CAMERA, previewUseCase, analysis)
            } catch (_: Exception) {
                ui { status.text = "Could not open the camera." }
            }
        }, ContextCompat.getMainExecutor(activity))
    }

    private fun ui(block: () -> Unit) { if (!closed) activity.runOnUiThread { block() } }

    private fun onFrame(faceFound: Boolean, sig: FloatArray?) {
        if (sig == null) {
            ui {
                status.text = if (faceFound) "Look straight at the camera" else "No face found. Move closer and add light"
                if (testMode) score.text = "—"
                guide.ringColor = accent; guide.invalidate()
            }
            return
        }
        if (testMode) {
            val s = FaceEngine.score(activity, sig)
            val ok = s <= threshold
            ui {
                guide.ringColor = if (ok) 0xFF3DDC84.toInt() else 0xFFFF5A6E.toInt(); guide.progress = 1f; guide.invalidate()
                status.text = if (ok) "✓ Face matched" else "✗ Face not matched"
                score.text = String.format(Locale.US, "Score %.3f  (match if ≤ %.3f)", s, threshold)
            }
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastSampleAt < 350 || samples.size >= FaceEngine.SAMPLES_NEEDED) return
        lastSampleAt = now
        samples.add(sig)
        val done = samples.size >= FaceEngine.SAMPLES_NEEDED
        if (done) {
            FaceEngine.saveTemplates(activity, samples.toList())
            saved = true
        }
        ui {
            guide.ringColor = accent
            guide.progress = samples.size / FaceEngine.SAMPLES_NEEDED.toFloat(); guide.invalidate()
            if (done) {
                guide.ringColor = 0xFF3DDC84.toInt(); guide.invalidate()
                status.text = "✓ Face saved"
                button.text = "Done"
                guide.postDelayed({ if (dialog.isShowing) dialog.dismiss() }, 900)
            } else {
                status.text = "Hold still, then slowly tilt your head a little left and right  (${samples.size}/${FaceEngine.SAMPLES_NEEDED})"
            }
        }
    }

    private fun stopCamera() {
        closed = true
        provider?.unbindAll()
        executor.execute { try { landmarker?.close() } catch (_: Exception) {}; landmarker = null }
        executor.shutdown()
    }
}
