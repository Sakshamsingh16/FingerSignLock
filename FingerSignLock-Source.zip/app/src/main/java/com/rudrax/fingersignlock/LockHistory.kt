package com.rudrax.fingersignlock

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LockHistory {
    private const val PREFS = "fsl_settings"
    private const val KEY_TIMES = "lock_times"
    private const val KEY_COUNT = "lock_count"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun recordLock(context: Context) {
        val p = prefs(context)
        val now = System.currentTimeMillis()
        val old = p.getString(KEY_TIMES, "").orEmpty().split(',').filter { it.isNotBlank() }
        val updated = (listOf(now.toString()) + old).take(50)
        p.edit().putString(KEY_TIMES, updated.joinToString(","))
            .putInt(KEY_COUNT, p.getInt(KEY_COUNT, 0) + 1).apply()
    }

    fun totalLocks(context: Context): Int = prefs(context).getInt(KEY_COUNT, 0)

    fun recentLocks(context: Context, limit: Int = 8): List<String> {
        val values = prefs(context).getString(KEY_TIMES, "").orEmpty()
            .split(',').filter { it.isNotBlank() }.take(limit)
        return values.mapNotNull { value ->
            value.toLongOrNull()?.let {
                SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault()).format(Date(it))
            }
        }
    }

    fun clear(context: Context) {
        prefs(context).edit().remove(KEY_TIMES).putInt(KEY_COUNT, 0).apply()
    }
}
