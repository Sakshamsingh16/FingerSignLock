package com.rudrax.fingersignlock

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Lightweight on-device face check.
 *
 * It does NOT store a photo. It stores face-shape measurements (distances between ~60 face-mesh
 * landmarks, divided by the distance between the eyes), which do not depend on how far you are
 * from the camera or on head tilt. This is a convenience filter, not secure biometric
 * authentication: a very similar looking person or a photo could pass.
 */
object FaceEngine {
    const val MODEL = "face_landmarker.task"
    private const val FILE = "face_templates.bin"
    const val SAMPLES_NEEDED = 16

    // Mean absolute difference (in "eye distance" units) allowed for a match.
    // Index = strictness: 0 Strict, 1 Balanced, 2 Relaxed.
    private val THRESHOLDS = floatArrayOf(0.030f, 0.040f, 0.055f)
    fun threshold(strictness: Int) = THRESHOLDS[strictness.coerceIn(0, 2)]

    // Stable MediaPipe face-mesh points: face outline, brows, eyes, nose, mouth.
    private val IDX = intArrayOf(
        10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152,
        148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109,
        33, 133, 159, 145, 362, 263, 386, 374,
        70, 63, 105, 66, 107, 300, 293, 334, 296, 336,
        1, 2, 4, 6, 98, 168, 327,
        61, 291, 13, 14, 0, 17
    )

    @Volatile private var cache: List<FloatArray>? = null

    fun createLandmarker(context: Context): FaceLandmarker {
        val options = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL).build())
            .setRunningMode(RunningMode.IMAGE)
            .setNumFaces(1)
            .build()
        return FaceLandmarker.createFromOptions(context, options)
    }

    /** Camera frames arrive sideways on most phones; rotate so the face is upright. */
    fun rotate(src: Bitmap, degrees: Int): Bitmap {
        if (degrees % 360 == 0) return src
        val m = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /** Returns null when the face is too small or turned too far away to measure reliably. */
    fun signature(lm: List<NormalizedLandmark>, w: Int, h: Int): FloatArray? {
        if (lm.size < 468) return null
        fun x(i: Int) = lm[i].x() * w
        fun y(i: Int) = lm[i].y() * h
        fun z(i: Int) = lm[i].z() * w
        fun d3(a: Int, b: Int): Float {
            val dx = x(a) - x(b); val dy = y(a) - y(b); val dz = z(a) - z(b)
            return sqrt(dx * dx + dy * dy + dz * dz)
        }
        fun d2(a: Int, b: Int): Float {
            val dx = x(a) - x(b); val dy = y(a) - y(b)
            return sqrt(dx * dx + dy * dy)
        }
        val eye = d3(33, 263)
        if (eye < 0.10f * w) return null
        val left = d2(1, 33); val right = d2(1, 263)
        if (right <= 0f) return null
        val ratio = left / right
        if (ratio < 0.70f || ratio > 1.43f) return null // head turned too far sideways

        val n = IDX.size
        val out = FloatArray(n * (n - 1) / 2)
        var k = 0
        for (i in 0 until n - 1) for (j in i + 1 until n) {
            out[k++] = d3(IDX[i], IDX[j]) / eye
        }
        return out
    }

    private fun diff(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return Float.MAX_VALUE
        var s = 0f
        for (i in a.indices) s += abs(a[i] - b[i])
        return s / a.size
    }

    /** Lower is more similar. Averages the 3 closest saved samples. */
    fun score(context: Context, sig: FloatArray): Float {
        val t = loadTemplates(context)
        if (t.isEmpty()) return Float.MAX_VALUE
        val best = t.map { diff(it, sig) }.sorted().take(3)
        return best.average().toFloat()
    }

    fun isMatch(context: Context, sig: FloatArray): Boolean {
        val strictness = context.getSharedPreferences("fsl_settings", Context.MODE_PRIVATE).getInt("face_strictness", 1)
        return score(context, sig) <= threshold(strictness)
    }

    // ───── storage (private app storage, numbers only, no images) ─────
    fun hasEnrolled(context: Context) = loadTemplates(context).isNotEmpty()

    fun saveTemplates(context: Context, list: List<FloatArray>) {
        if (list.isEmpty()) return
        DataOutputStream(File(context.filesDir, FILE).outputStream().buffered()).use { o ->
            o.writeInt(list.size); o.writeInt(list[0].size)
            for (t in list) for (f in t) o.writeFloat(f)
        }
        cache = list
    }

    fun loadTemplates(context: Context): List<FloatArray> {
        cache?.let { return it }
        val f = File(context.filesDir, FILE)
        if (!f.exists()) return emptyList()
        return try {
            DataInputStream(f.inputStream().buffered()).use { i ->
                val count = i.readInt(); val dim = i.readInt()
                List(count) { FloatArray(dim) { i.readFloat() } }
            }.also { cache = it }
        } catch (_: Exception) { emptyList() }
    }

    fun clear(context: Context) {
        File(context.filesDir, FILE).delete()
        cache = null
        context.getSharedPreferences("fsl_settings", Context.MODE_PRIVATE).edit().putBoolean("face_lock_enabled", false).apply()
    }
}
