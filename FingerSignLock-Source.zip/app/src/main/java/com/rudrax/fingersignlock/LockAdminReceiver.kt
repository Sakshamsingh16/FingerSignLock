package com.rudrax.fingersignlock

import android.app.admin.DeviceAdminReceiver

class LockAdminReceiver : DeviceAdminReceiver()
