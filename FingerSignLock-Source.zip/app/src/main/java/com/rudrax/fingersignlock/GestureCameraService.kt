package com.rudrax.fingersignlock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.hypot

class GestureCameraService : LifecycleService() {
    private lateinit var cameraExecutor: ExecutorService
    private var handLandmarker: HandLandmarker? = null
    private var cameraProvider: ProcessCameraProvider? = null
    @Volatile private var lastLockAt = 0L
    @Volatile private var gestureStartedAt = 0L
    private var faceLandmarker: FaceLandmarker? = null
    @Volatile private var faceWaitStartedAt = 0L
    @Volatile private var denyNotified = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        cameraExecutor = Executors.newSingleThreadExecutor()
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        createHandLandmarker()
        startCameraAnalysis()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return Service.START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Finger Sign Lock detection",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when hand-gesture phone locking is active."
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
            nm.createNotificationChannel(
                NotificationChannel(FACE_CHANNEL_ID, "Face verification alerts", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Tells you when an OK sign was shown but the face did not match."
                }
            )
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Finger Sign Lock is active")
            .setContentText("On-device gesture detection is active. Show OK 👌 to lock.")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun adminComponent() = ComponentName(this, LockAdminReceiver::class.java)

    private fun createHandLandmarker() {
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
            .setRunningMode(RunningMode.IMAGE)
            .setNumHands(2)
            .build()
        handLandmarker = HandLandmarker.createFromOptions(this, options)
    }

    private fun startCameraAnalysis() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                cameraProvider = provider
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(cameraExecutor) { image -> analyzeFrame(image) }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (_: Exception) {
                stopSelf()
            }
        }, androidx.core.content.ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            val bitmap = image.toBitmap()
            val result = handLandmarker?.detect(BitmapImageBuilder(bitmap).build())
            val hands = result?.landmarks().orEmpty()
            val isOk = hands.any { looksLikeOkGesture(it) }
            val now = SystemClock.elapsedRealtime()
            if (isOk) {
                if (gestureStartedAt == 0L) gestureStartedAt = now
            } else {
                gestureStartedAt = 0L
                faceWaitStartedAt = 0L
                denyNotified = false
            }

            val prefs = getSharedPreferences("fsl_settings", Context.MODE_PRIVATE)
            val holdMs = prefs.getLong("hold_ms", 800L).coerceIn(400L, 2000L)
            val cooldownMs = prefs.getInt("cooldown_sec", 5).coerceIn(5, 30) * 1000L
            if (isOk && gestureStartedAt != 0L && now - gestureStartedAt >= holdMs && now - lastLockAt >= cooldownMs) {
                if (prefs.getBoolean("face_lock_enabled", false)) {
                    val verdict = verifyFace(bitmap, image.imageInfo.rotationDegrees)
                    if (verdict != FACE_MATCH) {
                        // Keep re-checking every frame while the sign is held. Only warn once
                        // if the face still isn't recognised after a short grace period.
                        if (faceWaitStartedAt == 0L) faceWaitStartedAt = now
                        if (!denyNotified && now - faceWaitStartedAt >= 1500L) {
                            denyNotified = true
                            notifyFaceDenied(verdict)
                        }
                        return
                    }
                }
                val manager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                if (manager.isAdminActive(adminComponent())) {
                    lastLockAt = now
                    gestureStartedAt = 0L
                    faceWaitStartedAt = 0L
                    denyNotified = false
                    LockHistory.recordLock(this)
                    manager.lockNow()
                }
            }
        } catch (_: Exception) {
            // Ignore transient camera/inference errors and try the next frame.
        } finally {
            image.close()
        }
    }

    private fun verifyFace(bitmap: Bitmap, rotation: Int): Int {
        if (!FaceEngine.hasEnrolled(this)) return FACE_NOT_ENROLLED
        return try {
            val lm = faceLandmarker ?: FaceEngine.createLandmarker(this).also { faceLandmarker = it }
            val upright = FaceEngine.rotate(bitmap, rotation)
            val result = lm.detect(BitmapImageBuilder(upright).build())
            val face = result.faceLandmarks().firstOrNull()
            val sig = if (face != null) FaceEngine.signature(face, upright.width, upright.height) else null
            when {
                sig == null -> FACE_NOT_SEEN
                FaceEngine.isMatch(this, sig) -> FACE_MATCH
                else -> FACE_MISMATCH
            }
        } catch (_: Exception) {
            FACE_ERROR
        }
    }

    private fun notifyFaceDenied(verdict: Int) {
        val text = when (verdict) {
            FACE_NOT_SEEN -> "OK sign seen, but your face wasn't visible. Phone not locked."
            FACE_NOT_ENROLLED -> "Face lock is on but no face is saved. Open the app to set it up."
            FACE_ERROR -> "Face check is unavailable right now. Phone not locked."
            else -> "OK sign seen, but the face didn't match. Phone not locked."
        }
        val notification = NotificationCompat.Builder(this, FACE_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Face not recognised")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(FACE_NOTIFICATION_ID, notification)
        } catch (_: Exception) {
        }
    }

    private fun looksLikeOkGesture(points: List<NormalizedLandmark>): Boolean {
        if (points.size < 21) return false

        fun d(a: Int, b: Int): Float {
            val dx = points[a].x() - points[b].x()
            val dy = points[a].y() - points[b].y()
            return hypot(dx, dy)
        }

        // Scale thresholds to the hand size so left/right hands and near/far hands
        // are treated consistently. Landmark indices are the same for both hands.
        val prefs = getSharedPreferences("fsl_settings", Context.MODE_PRIVATE)
        val sensitivity = prefs.getInt("sensitivity", 1).coerceIn(0, 2)
        val palmWidth = d(5, 17).coerceAtLeast(0.04f)
        val thumbIndexGap = d(4, 8)
        val gapFactor = when (sensitivity) {
            0 -> 0.30f // Low sensitivity: stricter loop matching
            2 -> 0.56f // High sensitivity: more tolerant of hand pose/camera angle
            else -> 0.42f
        }
        val thumbAndIndexTouch = thumbIndexGap < palmWidth * gapFactor

        // In an OK sign, middle, ring and little fingers are extended while thumb
        // and index fingertips form a small loop. Wrist-relative distances work
        // for either hand and for rotated camera views better than vertical tests.
        fun fingerExtended(tip: Int, pip: Int): Boolean {
            return d(tip, 0) > d(pip, 0) * 1.12f
        }

        val middleExtended = fingerExtended(12, 10)
        val ringExtended = fingerExtended(16, 14)
        val pinkyExtended = fingerExtended(20, 18)

        return thumbAndIndexTouch && middleExtended && ringExtended && pinkyExtended
    }

    override fun onDestroy() {
        isRunning = false
        cameraProvider?.unbindAll()
        handLandmarker?.close()
        try { faceLandmarker?.close() } catch (_: Exception) {}
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
        super.onDestroy()
    }

    companion object {
        @Volatile var isRunning: Boolean = false
            private set
        private const val CHANNEL_ID = "finger_sign_lock_detection"
        private const val NOTIFICATION_ID = 42
        private const val FACE_CHANNEL_ID = "finger_sign_lock_face"
        private const val FACE_NOTIFICATION_ID = 43
        private const val FACE_MATCH = 0
        private const val FACE_NOT_SEEN = 1
        private const val FACE_MISMATCH = 2
        private const val FACE_NOT_ENROLLED = 3
        private const val FACE_ERROR = 4
    }
}
