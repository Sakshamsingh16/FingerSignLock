\
package com.rudrax.fingersignlock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.hypot

class GestureCameraService : LifecycleService() {
    private lateinit var cameraExecutor: ExecutorService
    private var handLandmarker: HandLandmarker? = null
    private var cameraProvider: ProcessCameraProvider? = null
    @Volatile private var lastLockAt = 0L
    @Volatile private var consecutiveOkFrames = 0

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        cameraExecutor = Executors.newSingleThreadExecutor()
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        createHandLandmarker()
        startCameraAnalysis()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return Service.START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Finger Sign Lock detection",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows when hand-gesture phone locking is active."
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Finger Sign Lock is active")
            .setContentText("Show an OK 👌 sign with either hand to lock the phone.")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun adminComponent() = ComponentName(this, LockAdminReceiver::class.java)

    private fun createHandLandmarker() {
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
            .setRunningMode(RunningMode.IMAGE)
            .setNumHands(2)
            .build()
        handLandmarker = HandLandmarker.createFromOptions(this, options)
    }

    private fun startCameraAnalysis() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                cameraProvider = provider
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(cameraExecutor) { image -> analyzeFrame(image) }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (_: Exception) {
                stopSelf()
            }
        }, androidx.core.content.ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            val bitmap = image.toBitmap()
            val result = handLandmarker?.detect(BitmapImageBuilder(bitmap).build())
            val hands = result?.landmarks().orEmpty()
            val isOk = hands.any { looksLikeOkGesture(it) }
            if (isOk) consecutiveOkFrames++ else consecutiveOkFrames = 0

            if (consecutiveOkFrames >= 5 &&
                SystemClock.elapsedRealtime() - lastLockAt > 5000L) {
                lastLockAt = SystemClock.elapsedRealtime()
                consecutiveOkFrames = 0
                val manager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                if (manager.isAdminActive(adminComponent())) {
                    manager.lockNow()
                }
            }
        } catch (_: Exception) {
            // Ignore transient camera/inference errors and try the next frame.
        } finally {
            image.close()
        }
    }

    private fun looksLikeOkGesture(points: List<NormalizedLandmark>): Boolean {
        if (points.size < 21) return false

        fun d(a: Int, b: Int): Float {
            val dx = points[a].x() - points[b].x()
            val dy = points[a].y() - points[b].y()
            return hypot(dx, dy)
        }

        // Works for either left or right hand: use distances from the wrist rather than
        // assuming that extended fingers always point toward the top of the image.
        val thumbAndIndexTouch = d(4, 8) < 0.11f
        fun extended(tip: Int, pip: Int, mcp: Int): Boolean {
            return d(tip, 0) > d(pip, 0) * 1.12f &&
                   d(tip, mcp) > d(pip, mcp) * 0.75f
        }

        val middleExtended = extended(12, 10, 9)
        val ringExtended = extended(16, 14, 13)
        val pinkyExtended = extended(20, 18, 17)
        return thumbAndIndexTouch && middleExtended && ringExtended && pinkyExtended
    }

    override fun onDestroy() {
        isRunning = false
        cameraProvider?.unbindAll()
        handLandmarker?.close()
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
        super.onDestroy()
    }

    companion object {
        @Volatile var isRunning: Boolean = false
            private set
        private const val CHANNEL_ID = "finger_sign_lock_detection"
        private const val NOTIFICATION_ID = 42
    }
}
