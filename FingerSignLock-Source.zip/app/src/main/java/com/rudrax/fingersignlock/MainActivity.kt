package com.rudrax.fingersignlock

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.hypot

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var toggleButton: Button
    private lateinit var cameraExecutor: ExecutorService
    private var handLandmarker: HandLandmarker? = null
    @Volatile private var detecting = false
    @Volatile private var lastLockAt = 0L
    @Volatile private var consecutiveOkFrames = 0
    private var cameraProvider: ProcessCameraProvider? = null

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else status.text = "Camera permission is required to detect your hand."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        createHandLandmarker()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            setBackgroundColor(Color.rgb(16, 16, 24))
        }
        val heading = TextView(this).apply {
            text = "FINGER SIGN LOCK"
            textSize = 24f
            setTextColor(Color.rgb(0, 214, 219))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Show an OK 👌 gesture to lock your phone"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        status = TextView(this).apply {
            text = "Preparing hand detection…"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 14)
        }
        toggleButton = Button(this).apply {
            text = "Start gesture detection"
            setOnClickListener {
                if (!isAdminActive()) {
                    val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
                        putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            "Allow Finger Sign Lock to lock this device when the OK hand gesture is detected.")
                    }
                    startActivity(intent)
                    status.text = "Enable device administrator, then tap Start again."
                    return@setOnClickListener
                }
                detecting = !detecting
                text = if (detecting) "Stop gesture detection" else "Start gesture detection"
                status.text = if (detecting) "Detection is ON. Keep the OK gesture visible." else "Detection is paused."
            }
        }
        container.addView(heading)
        container.addView(subtitle)
        container.addView(previewView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        container.addView(status)
        container.addView(toggleButton)
        setContentView(container)
    }

    private fun adminComponent() = ComponentName(this, LockAdminReceiver::class.java)

    private fun isAdminActive(): Boolean {
        val manager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return manager.isAdminActive(adminComponent())
    }

    private fun createHandLandmarker() {
        try {
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                .setRunningMode(RunningMode.IMAGE)
                .setNumHands(1)
                .build()
            handLandmarker = HandLandmarker.createFromOptions(this, options)
            status.text = "Ready. Enable device lock, then start detection."
        } catch (e: Exception) {
            status.text = "Could not load hand model. Rebuild from the supplied GitHub workflow."
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                cameraProvider = provider
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(cameraExecutor) { image ->
                    analyzeFrame(image)
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
            } catch (e: Exception) {
                runOnUiThread { status.text = "Could not start front camera: ${e.message ?: "unknown error"}" }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            if (!detecting || handLandmarker == null) {
                consecutiveOkFrames = 0
                return
            }
            val bitmap = image.toBitmap()
            val mpImage = BitmapImageBuilder(bitmap).build()
            val result = handLandmarker?.detect(mpImage)
            val landmarks = result?.landmarks()?.firstOrNull()
            val isOk = landmarks != null && looksLikeOkGesture(landmarks)
            if (isOk) consecutiveOkFrames++ else consecutiveOkFrames = 0

            if (consecutiveOkFrames >= 5 && SystemClock.elapsedRealtime() - lastLockAt > 5000L) {
                lastLockAt = SystemClock.elapsedRealtime()
                consecutiveOkFrames = 0
                runOnUiThread { status.text = "OK gesture detected — locking phone…" }
                if (isAdminActive()) {
                    (getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).lockNow()
                } else {
                    runOnUiThread { status.text = "Enable device administrator first." }
                }
            }
        } catch (_: Exception) {
            // Ignore occasional frame conversion or inference errors; continue on the next frame.
        } finally {
            image.close()
        }
    }

    private fun looksLikeOkGesture(points: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Boolean {
        if (points.size < 21) return false
        fun d(a: Int, b: Int): Float {
            val dx = points[a].x() - points[b].x()
            val dy = points[a].y() - points[b].y()
            return hypot(dx, dy)
        }
        // Thumb tip (4) and index tip (8) close together; remaining three fingers extended.
        val thumbIndexTouching = d(4, 8) < 0.075f
        val middleExtended = points[12].y() < points[10].y()
        val ringExtended = points[16].y() < points[14].y()
        val pinkyExtended = points[20].y() < points[18].y()
        return thumbIndexTouching && middleExtended && ringExtended && pinkyExtended
    }

    override fun onDestroy() {
        detecting = false
        cameraProvider?.unbindAll()
        handLandmarker?.close()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
