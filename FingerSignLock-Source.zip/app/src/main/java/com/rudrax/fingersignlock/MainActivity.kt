package com.rudrax.fingersignlock

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var statusDot: TextView
    private lateinit var toggleButton: TextView
    private lateinit var adminState: TextView
    private lateinit var cameraState: TextView

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        refreshUi(if (granted) "Camera permission granted. Tap Start Detection." else "Camera permission is required.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 10, 25)
        window.navigationBarColor = Color.rgb(8, 10, 25)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun gradient(radius: Int = 22): GradientDrawable =
        GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(130, 47, 255), Color.rgb(46, 88, 255), Color.rgb(20, 202, 222))
        ).apply { cornerRadius = dp(radius).toFloat() }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(Color.rgb(20, 24, 45), 22, Color.rgb(47, 54, 88))
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(8, 10, 25))
            isFillViewport = true
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.finger_sign_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.BLACK, 18, Color.rgb(132, 64, 255))
            clipToOutline = true
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(62), dp(62)))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        brand.addView(label("FINGER SIGN", 20f, Color.WHITE, true))
        brand.addView(label("LOCK", 20f, Color.rgb(192, 99, 255), true))
        brand.addView(label("GESTURE TO LOCK YOUR PHONE", 9f, Color.rgb(160, 173, 213), true))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(label("v1.0", 12f, Color.rgb(159, 171, 208)))
        page.addView(top)
        page.addView(space(20))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(22), dp(18), dp(22))
            background = gradient(26)
        }
        hero.addView(label("Lock with a simple gesture", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        hero.addView(space(8))
        hero.addView(label("Show the OK 👌 sign with either hand", 14f, Color.WHITE).apply { gravity = Gravity.CENTER })
        hero.addView(space(16))
        val heroIcon = ImageView(this).apply {
            setImageResource(R.drawable.finger_sign_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(11, 12, 34), 80, Color.rgb(198, 105, 255))
            clipToOutline = true
        }
        hero.addView(heroIcon, LinearLayout.LayoutParams(dp(118), dp(118)))
        page.addView(hero)
        page.addView(space(16))

        val stateCard = card()
        val stateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        statusDot = label("●", 20f, Color.rgb(255, 177, 65), true)
        stateRow.addView(statusDot)
        val stateTexts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        stateTexts.addView(label("Detection status", 17f, Color.WHITE, true))
        status = label("Checking service status…", 13f, Color.rgb(174, 185, 218))
        stateTexts.addView(status)
        stateRow.addView(stateTexts, LinearLayout.LayoutParams(0, -2, 1f))
        stateCard.addView(stateRow)
        stateCard.addView(space(16))
        toggleButton = label("▶   START GESTURE DETECTION", 15f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(17), dp(14), dp(17))
            background = gradient(18)
            isClickable = true
            isFocusable = true
            setOnClickListener { toggleDetection() }
        }
        stateCard.addView(toggleButton)
        stateCard.addView(space(10))
        stateCard.addView(label("Keep the persistent notification visible while detection is active.", 12f, Color.rgb(164, 176, 209)))
        page.addView(stateCard)
        page.addView(space(16))

        page.addView(label("READY CHECK", 12f, Color.rgb(170, 124, 255), true))
        page.addView(space(8))
        val checks = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cameraCard = miniStatusCard("📷", "Camera", "Checking…")
        cameraState = cameraCard.second
        val adminCard = miniStatusCard("🛡️", "Lock permission", "Checking…")
        adminState = adminCard.second
        checks.addView(cameraCard.first, LinearLayout.LayoutParams(0, -1, 1f).apply { marginEnd = dp(7) })
        checks.addView(adminCard.first, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = dp(7) })
        page.addView(checks)
        page.addView(space(16))

        val tips = card()
        tips.addView(label("HOW TO USE", 13f, Color.rgb(177, 125, 255), true))
        tips.addView(space(8))
        tips.addView(label("1. Enable Camera and Device Administrator permissions.", 14f, Color.WHITE))
        tips.addView(space(6))
        tips.addView(label("2. Tap Start Detection and keep the camera uncovered.", 14f, Color.WHITE))
        tips.addView(space(6))
        tips.addView(label("3. Show a clear OK 👌 gesture with your left or right hand.", 14f, Color.WHITE))
        tips.addView(space(10))
        tips.addView(label("Background use depends on Android camera and battery restrictions.", 12f, Color.rgb(159, 173, 210)))
        page.addView(tips)
        page.addView(space(16))
        page.addView(label("FINGER SIGN LOCK  •  MADE FOR SIMPLE, HANDS-FREE LOCKING", 10f, Color.rgb(107, 119, 160)).apply {
            gravity = Gravity.CENTER
        })

        scroll.addView(page)
        setContentView(scroll)
        refreshUi()
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun miniStatusCard(emoji: String, title: String, initial: String): Pair<LinearLayout, TextView> {
        val c = card()
        c.addView(label(emoji, 22f, Color.WHITE))
        c.addView(space(8))
        c.addView(label(title, 14f, Color.WHITE, true))
        val value = label(initial, 12f, Color.rgb(160, 225, 190))
        c.addView(value)
        return c to value
    }

    private fun adminComponent() = ComponentName(this, LockAdminReceiver::class.java)

    private fun isAdminActive(): Boolean {
        val manager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return manager.isAdminActive(adminComponent())
    }

    private fun toggleDetection() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA)
            return
        }
        if (GestureCameraService.isRunning) {
            stopService(Intent(this, GestureCameraService::class.java))
            refreshUi("Gesture detection stopped.")
            return
        }
        if (!isAdminActive()) {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allow Finger Sign Lock to lock the device when an OK hand gesture is detected.")
            }
            startActivity(intent)
            refreshUi("Enable Device Administrator, return here, then tap Start.")
            return
        }
        val intent = Intent(this, GestureCameraService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        refreshUi("Starting detection. Keep the ongoing notification visible.")
    }

    private fun refreshUi(message: String? = null) {
        if (!::status.isInitialized) return
        val running = GestureCameraService.isRunning
        status.text = message ?: if (running) "Active — gesture detection running" else "Off — tap Start Detection"
        statusDot.setTextColor(if (running) Color.rgb(57, 230, 142) else Color.rgb(255, 177, 65))
        toggleButton.text = if (running) "■   STOP GESTURE DETECTION" else "▶   START GESTURE DETECTION"
        toggleButton.background = if (running) rounded(Color.rgb(191, 35, 77), 18) else gradient(18)
        cameraState.text = if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) "Granted ✓" else "Needed"
        adminState.text = if (isAdminActive()) "Enabled ✓" else "Needed"
        cameraState.setTextColor(if (cameraState.text.toString().contains("✓")) Color.rgb(87, 232, 159) else Color.rgb(255, 177, 65))
        adminState.setTextColor(if (adminState.text.toString().contains("✓")) Color.rgb(87, 232, 159) else Color.rgb(255, 177, 65))
    }
}
