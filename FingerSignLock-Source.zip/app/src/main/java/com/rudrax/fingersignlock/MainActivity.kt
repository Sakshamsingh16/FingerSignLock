package com.rudrax.fingersignlock

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var toggleButton: Button
    private var detecting = false

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) refreshUi("Camera permission granted. Tap Start to begin.")
        else refreshUi("Camera permission is required for gesture detection.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onResume() {
        super.onResume()
        detecting = GestureCameraService.isRunning
        refreshUi()
    }

    private fun buildUi() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            setBackgroundColor(Color.rgb(16, 16, 24))
        }
        val heading = TextView(this).apply {
            text = "FINGER SIGN LOCK"
            textSize = 24f
            setTextColor(Color.rgb(0, 214, 219))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Show an OK 👌 gesture with either hand to lock your phone"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        }
        val info = TextView(this).apply {
            text = "Background detection stays active while the foreground-service notification is visible. Keep the front camera uncovered."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(20, 20, 20, 20)
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 14)
        }
        toggleButton = Button(this).apply {
            setOnClickListener { toggleDetection() }
        }
        container.addView(heading)
        container.addView(subtitle)
        container.addView(info, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        container.addView(status)
        container.addView(toggleButton)
        setContentView(container)
        refreshUi()
    }

    private fun adminComponent() = ComponentName(this, LockAdminReceiver::class.java)

    private fun isAdminActive(): Boolean {
        val manager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return manager.isAdminActive(adminComponent())
    }

    private fun toggleDetection() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA)
            return
        }

        if (GestureCameraService.isRunning) {
            stopService(Intent(this, GestureCameraService::class.java))
            detecting = false
            refreshUi("Gesture detection stopped.")
            return
        }

        if (!isAdminActive()) {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Allow Finger Sign Lock to lock this device when an OK hand gesture is detected."
                )
            }
            startActivity(intent)
            refreshUi("Enable Device Administrator, return here, then tap Start.")
            return
        }

        val intent = Intent(this, GestureCameraService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        detecting = true
        refreshUi("Starting detection. You can minimize the app; keep the service notification visible.")
    }

    private fun refreshUi(message: String? = null) {
        if (!::status.isInitialized) return
        toggleButton.text = if (detecting) "STOP GESTURE DETECTION" else "START GESTURE DETECTION"
        status.text = message ?: if (detecting) {
            "Detection is ON, including while minimized."
        } else {
            "Detection is OFF. Enable Device Administrator before starting."
        }
    }
}
