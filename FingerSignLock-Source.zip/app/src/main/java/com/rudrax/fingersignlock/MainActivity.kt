package com.rudrax.fingersignlock

import android.Manifest
import android.animation.ValueAnimator
import android.app.Dialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : AppCompatActivity() {

    // ───────────── EDIT THESE: developer details shown on the Info tab ─────────────
    private object Dev {
        const val NAME = "Saksham"
        const val ROLE = "Independent Android Developer"
        const val ABOUT = "I build Android apps, tools and games. Finger Sign Lock is made with care for people who want a faster, smarter way to lock their phone."
        const val EMAIL = ""    // e.g. "you@example.com"  (empty = row hidden)
        const val GITHUB = ""   // e.g. "https://github.com/yourname"  (empty = row hidden)
        const val WEBSITE = ""  // e.g. "https://yoursite.com"  (empty = row hidden)
    }

    // ───────────── Prefs keys (same file the service reads) ─────────────
    private companion object {
        const val K_MODE = "ui_mode"       // 0 dark, 1 light, 2 system
        const val K_ACCENT = "ui_accent"   // 0 red, 1 green, 2 yellow
        const val K_START = "session_start"
        const val K_FACE_ON = "face_lock_enabled"
        const val K_FACE_STRICT = "face_strictness" // 0 strict, 1 balanced, 2 relaxed
    }

    // ───────────── Theme ─────────────
    private class AccentDef(val name: String, val main: Int, val deep: Int, val onAccent: Int, val lightDarken: Float)
    private class Pal(
        val dark: Boolean, val bg: Int, val surface: Int, val surface2: Int, val stroke: Int,
        val text: Int, val sub: Int, val accent: Int, val accentDeep: Int, val onAccent: Int, val accentFg: Int,
        val ok: Int, val warn: Int, val bad: Int
    )

    private val accents = listOf(
        AccentDef("Red", 0xFFFF304A.toInt(), 0xFFB3122F.toInt(), Color.WHITE, 0.22f),
        AccentDef("Green", 0xFF0EA55F.toInt(), 0xFF056B40.toInt(), Color.WHITE, 0.15f),
        AccentDef("Yellow", 0xFFFFC107.toInt(), 0xFFE08A00.toInt(), 0xFF1B1300.toInt(), 0.45f)
    )
    private lateinit var c: Pal

    // ───────────── State ─────────────
    private var currentTab = 0
    private var tabHost: FrameLayout? = null
    private var scrollView: ScrollView? = null
    private var navBar: LinearLayout? = null
    private val navPills = mutableListOf<FrameLayout>()
    private val navIcons = mutableListOf<ImageView>()
    private val navLabels = mutableListOf<TextView>()
    private var homeRefresh: (() -> Unit)? = null
    private var pulseAnim: ValueAnimator? = null
    private var flashMsg: String? = null
    private var flashUntil = 0L
    private val openSections = mutableSetOf("How to use")
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { refreshUi(); handler.postDelayed(this, 1000) }
    }

    private lateinit var notificationPermissionLauncher: ActivityResultLauncher<String>

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        flash(if (granted) "Camera permission granted." else "Camera permission is required for gesture detection.")
        if (granted) requestNotificationPermissionIfNeeded()
    }

    // ───────────── Lifecycle ─────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        currentTab = savedInstanceState?.getInt("tab", 0) ?: 0
        notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
        buildUi()
        if (!hasCamera()) cameraPermission.launch(Manifest.permission.CAMERA) else requestNotificationPermissionIfNeeded()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", currentTab)
    }

    override fun onResume() {
        super.onResume()
        if (currentTab == 1) rebuild()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        stopPulse(null)
        super.onPause()
    }

    // ───────────── Small helpers ─────────────
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun prefs() = getSharedPreferences("fsl_settings", Context.MODE_PRIVATE)
    private fun mix(a: Int, b: Int, t: Float) = ColorUtils.blendARGB(a, b, t)
    private fun alpha(color: Int, a: Int) = ColorUtils.setAlphaComponent(color, a)
    private fun hasCamera() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun hasNotif() = NotificationManagerCompat.from(this).areNotificationsEnabled()
    private fun adminComponent() = ComponentName(this, LockAdminReceiver::class.java)
    private fun dpm() = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private fun isAdminActive(): Boolean = dpm().isAdminActive(adminComponent())
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun openSafe(i: Intent) {
        try { startActivity(i) } catch (_: Exception) { toast("Not available on this phone") }
    }

    private fun flash(msg: String) {
        flashMsg = msg; flashUntil = SystemClock.elapsedRealtime() + 3500
        refreshUi()
    }

    private fun refreshUi() { homeRefresh?.invoke() }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.3"
    } catch (_: Exception) { "1.3" }

    private fun ago(t: Long): String {
        val s = (System.currentTimeMillis() - t) / 1000
        return when {
            s < 60 -> "just now"
            s < 3600 -> "${s / 60}m ago"
            s < 86400 -> "${s / 3600}h ago"
            else -> "${s / 86400}d ago"
        }
    }

    private fun lockTimes(): List<Long> =
        prefs().getString("lock_times", "").orEmpty().split(',').mapNotNull { it.toLongOrNull() }

    private fun startOfToday(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    // ───────────── Palette ─────────────
    private fun buildPalette() {
        val a = accents[prefs().getInt(K_ACCENT, 0).coerceIn(0, 2)]
        val mode = prefs().getInt(K_MODE, 0).coerceIn(0, 2)
        val sysDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val dark = when (mode) { 0 -> true; 1 -> false; else -> sysDark }
        c = if (dark) Pal(
            dark = true,
            bg = mix(0xFF0A0A0F.toInt(), a.main, 0.07f),
            surface = mix(0xFF15151C.toInt(), a.main, 0.07f),
            surface2 = mix(0xFF1E1E27.toInt(), a.main, 0.12f),
            stroke = mix(0xFF2B2B36.toInt(), a.main, 0.28f),
            text = 0xFFF4F4F8.toInt(), sub = 0xFFA2A2B5.toInt(),
            accent = a.main, accentDeep = a.deep, onAccent = a.onAccent,
            accentFg = mix(a.main, Color.WHITE, 0.12f),
            ok = 0xFF3DDC84.toInt(), warn = 0xFFFFB02E.toInt(), bad = 0xFFFF5A6E.toInt()
        ) else Pal(
            dark = false,
            bg = mix(0xFFF5F5F9.toInt(), a.main, 0.05f),
            surface = Color.WHITE,
            surface2 = mix(Color.WHITE, a.main, 0.09f),
            stroke = mix(0xFFDEDEE8.toInt(), a.main, 0.25f),
            text = 0xFF14141C.toInt(), sub = 0xFF5E5E72.toInt(),
            accent = a.main, accentDeep = a.deep, onAccent = a.onAccent,
            accentFg = mix(a.main, Color.BLACK, a.lightDarken),
            ok = 0xFF138A4B.toInt(), warn = 0xFFB45309.toInt(), bad = 0xFFC81E3A.toInt()
        )
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }

    // ───────────── View factories ─────────────
    private fun rounded(color: Int, r: Int, stroke: Int? = null, strokeDp: Int = 1) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
        if (stroke != null) setStroke(dp(strokeDp), stroke)
    }

    private fun oval(color: Int, stroke: Int? = null, strokeDp: Int = 1) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(color)
        if (stroke != null) setStroke(dp(strokeDp), stroke)
    }

    private fun accentGrad(r: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(c.accent, c.accentDeep)
    ).apply { cornerRadius = dp(r).toFloat() }

    private fun withRipple(bg: Drawable, r: Int, rippleColor: Int): Drawable =
        RippleDrawable(ColorStateList.valueOf(rippleColor), bg, rounded(Color.WHITE, r))

    private fun tv(text: CharSequence, size: Float, color: Int, bold: Boolean = false, center: Boolean = false, spacing: Float = 1f): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            if (center) gravity = Gravity.CENTER
            if (spacing != 1f) setLineSpacing(0f, spacing)
        }

    private fun LinearLayout.addV(v: View, top: Int = 0, w: Int = MATCH, h: Int = WRAP) {
        addView(v, LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) })
    }

    private fun card(pad: Int = 16): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        background = rounded(c.surface, 22, c.stroke)
        if (!c.dark) elevation = dp(2).toFloat()
    }

    private fun sectionTitle(text: String): TextView =
        tv(text.uppercase(), 11.5f, c.accentFg, true).apply { letterSpacing = 0.1f }

    private fun divider(): View = View(this).apply { setBackgroundColor(alpha(c.stroke, 160)) }

    private fun chip(text: String, color: Int): TextView =
        tv(text, 11f, color, true).apply {
            setPadding(dp(10), dp(5), dp(10), dp(5)); background = rounded(alpha(color, 36), 10)
        }

    private fun setChip(v: TextView, text: String, color: Int) {
        v.text = text; v.setTextColor(color); v.background = rounded(alpha(color, 36), 10)
    }

    private fun iconBox(emoji: String, tint: Int): TextView =
        tv(emoji, 18f, c.text, false, true).apply { background = rounded(alpha(tint, 38), 12) }

    private fun primaryButton(text: String, onClick: () -> Unit): TextView =
        tv(text, 15f, c.onAccent, true, true).apply {
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = withRipple(accentGrad(16), 16, alpha(c.onAccent, 60))
            isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }

    private fun secondaryButton(text: String, color: Int = c.text, onClick: () -> Unit): TextView =
        tv(text, 14.5f, color, true, true).apply {
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = withRipple(rounded(c.surface2, 14, c.stroke), 14, alpha(color, 50))
            isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }

    private fun statusRow(emoji: String, title: String, sub: String, tint: Int, onClick: () -> Unit): Pair<LinearLayout, TextView> {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10)); isClickable = true
            setOnClickListener { onClick() }
        }
        r.addView(iconBox(emoji, tint), LinearLayout.LayoutParams(dp(40), dp(40)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        col.addView(tv(title, 14.5f, c.text, true)); col.addView(tv(sub, 12f, c.sub))
        r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val statusChip = chip("…", c.sub)
        r.addView(statusChip)
        return r to statusChip
    }

    private fun actionRow(emoji: String, title: String, sub: String, tint: Int, trailing: String = "›", onClick: () -> Unit): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10)); isClickable = true
            setOnClickListener { onClick() }
        }
        r.addView(iconBox(emoji, tint), LinearLayout.LayoutParams(dp(40), dp(40)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        col.addView(tv(title, 14.5f, c.text, true)); col.addView(tv(sub, 12f, c.sub))
        r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        r.addView(tv(trailing, 20f, c.sub))
        return r
    }

    private fun screenTitle(page: LinearLayout, title: String, sub: String) {
        page.addView(tv(title, 27f, c.text, true))
        page.addV(tv(sub, 13f, c.sub), 2)
    }

    private fun confirm(title: String, msg: String, action: String, danger: Boolean = false, onYes: () -> Unit) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = card(20).apply { background = rounded(c.surface, 26, c.stroke) }
        box.addView(tv(title, 18f, c.text, true))
        box.addV(tv(msg, 14f, c.sub, spacing = 1.2f), 8)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(secondaryButton("Cancel") { d.dismiss() }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
        val yes = if (danger) secondaryButton(action, c.bad) { d.dismiss(); onYes() }
        else primaryButton(action) { d.dismiss(); onYes() }
        row.addView(yes, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(6) })
        box.addV(row, 18)
        d.setContentView(box)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), WRAP)
        }
        d.show()
    }

    // ───────────── Root: tab host + bottom navigation ─────────────
    private fun buildUi() {
        buildPalette()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(c.bg) }
        tabHost = FrameLayout(this)
        root.addView(tabHost, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val nav = buildNavBar()
        navBar = nav
        root.addView(nav, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(0, b.top, 0, 0)
            navBar?.setPadding(0, 0, 0, b.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
        showTab(currentTab, animate = false)
    }

    private fun rebuild() {
        val y = scrollView?.scrollY ?: 0
        buildUi()
        scrollView?.post { scrollView?.scrollTo(0, y) }
    }

    private fun buildNavBar(): LinearLayout {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(c.surface) }
        bar.addView(View(this).apply { setBackgroundColor(c.stroke) }, LinearLayout.LayoutParams(MATCH, 1))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        navPills.clear(); navIcons.clear(); navLabels.clear()
        val names = listOf("Home", "Settings", "Info")
        val icons = listOf(R.drawable.ic_home, R.drawable.ic_settings, R.drawable.ic_info)
        names.forEachIndexed { i, name ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                setOnClickListener { if (currentTab != i) showTab(i) }
            }
            val pill = FrameLayout(this)
            val ic = ImageView(this).apply { setImageResource(icons[i]) }
            pill.addView(ic, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            item.addView(pill, LinearLayout.LayoutParams(dp(64), dp(32)))
            val label = tv(name, 11.5f, c.sub, true)
            item.addView(label, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(3) })
            row.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
            navPills.add(pill); navIcons.add(ic); navLabels.add(label)
        }
        bar.addView(row)
        return bar
    }

    private fun updateNav() {
        for (i in navPills.indices) {
            val sel = i == currentTab
            navPills[i].background = if (sel) rounded(alpha(c.accent, if (c.dark) 64 else 80), 16) else null
            navIcons[i].setColorFilter(if (sel) c.accentFg else c.sub)
            navLabels[i].setTextColor(if (sel) c.accentFg else c.sub)
        }
    }

    private fun showTab(i: Int, animate: Boolean = true) {
        currentTab = i
        stopPulse(null)
        homeRefresh = null
        val host = tabHost ?: return
        host.removeAllViews()
        val scroll = ScrollView(this).apply {
            isFillViewport = true; isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER
        }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(24)) }
        when (i) { 0 -> buildHome(page); 1 -> buildSettings(page); else -> buildInfo(page) }
        scroll.addView(page)
        host.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        scrollView = scroll
        updateNav()
        if (animate) {
            scroll.alpha = 0f; scroll.translationY = dp(10).toFloat()
            scroll.animate().alpha(1f).translationY(0f).setDuration(200).start()
        }
        refreshUi()
    }

    // ═════════════════════════ HOME (live dashboard) ═════════════════════════
    private fun buildHome(page: LinearLayout) {
        // Header
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.finger_sign_logo); scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.BLACK, 14, c.accent, 2); clipToOutline = true
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        titleBox.addView(tv("Finger Sign Lock", 19f, c.text, true))
        titleBox.addView(tv("Lock your phone with a gesture", 11.5f, c.sub))
        header.addView(titleBox, LinearLayout.LayoutParams(0, WRAP, 1f))
        val livePill = chip("● OFF", c.sub)
        header.addView(livePill)
        page.addView(header)

        // Hero: live status orb
        val hero = card(18).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(c.surface, mix(c.surface, c.accent, if (c.dark) 0.18f else 0.12f))
            ).apply { cornerRadius = dp(26).toFloat(); setStroke(dp(1), c.stroke) }
        }
        val orb = FrameLayout(this)
        val outerRing = View(this).apply { background = oval(Color.TRANSPARENT, alpha(c.accent, 80), 1) }
        val pulse = View(this).apply { background = oval(alpha(c.accent, 120)); alpha = 0f }
        val core = tv("👌", 52f, c.text, false, true)
        orb.addView(outerRing, FrameLayout.LayoutParams(dp(190), dp(190), Gravity.CENTER))
        orb.addView(pulse, FrameLayout.LayoutParams(dp(132), dp(132), Gravity.CENTER))
        orb.addView(core, FrameLayout.LayoutParams(dp(132), dp(132), Gravity.CENTER))
        hero.addView(orb, LinearLayout.LayoutParams(dp(200), dp(200)))
        val heroTitle = tv("Protection is OFF", 22f, c.text, true, true)
        val heroSub = tv("", 13.5f, c.sub, false, true, 1.15f)
        val uptime = chip("Not running", c.sub)
        val toggle = primaryButton("START DETECTION") { toggleDetection() }
        hero.addV(heroTitle, 6)
        hero.addV(heroSub, 6)
        hero.addV(uptime, 12, WRAP, WRAP)
        hero.addV(toggle, 16)
        page.addV(hero, 18)

        // Live stats
        val statsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun stat(label: String): Pair<LinearLayout, TextView> {
            val box = card(12).apply { gravity = Gravity.CENTER_HORIZONTAL }
            val v = tv("0", 22f, c.text, true, true)
            box.addView(v)
            box.addV(tv(label, 10f, c.sub, true, true).apply { letterSpacing = 0.06f }, 2)
            return box to v
        }
        val (totalBox, totalV) = stat("TOTAL LOCKS")
        val (todayBox, todayV) = stat("TODAY")
        val (lastBox, lastV) = stat("LAST LOCK")
        statsRow.addView(totalBox, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(5) })
        statsRow.addView(todayBox, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
        statsRow.addView(lastBox, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(5) })
        page.addV(statsRow, 14)

        // How it works (live hold time)
        page.addV(sectionTitle("How it works"), 22)
        val how = card(14)
        val steps = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun step(emoji: String, label: TextView): LinearLayout {
            val s = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            s.addView(iconBox(emoji, c.accent), LinearLayout.LayoutParams(dp(48), dp(48)))
            s.addV(label, 6)
            return s
        }
        val holdLabel = tv("Hold 0.8 s", 12f, c.text, true, true)
        steps.addView(step("👌", tv("Show sign", 12f, c.text, true, true)), LinearLayout.LayoutParams(0, WRAP, 1f))
        steps.addView(tv("›", 22f, c.sub))
        steps.addView(step("⏱", holdLabel), LinearLayout.LayoutParams(0, WRAP, 1f))
        steps.addView(tv("›", 22f, c.sub))
        steps.addView(step("🔒", tv("Phone locks", 12f, c.text, true, true)), LinearLayout.LayoutParams(0, WRAP, 1f))
        how.addView(steps)
        how.addV(tv("Works with either hand. Thumb and index finger touch, other three fingers open.", 12f, c.sub, false, true, 1.15f), 12)
        page.addV(how, 10)

        // Ready check
        page.addV(sectionTitle("Ready check"), 22)
        val checks = card(12)
        val (camRow, camChip) = statusRow("📷", "Camera", "Needed to see your hand", c.accent) {
            if (!hasCamera()) cameraPermission.launch(Manifest.permission.CAMERA)
        }
        val (adminRow, adminChip) = statusRow("🔐", "Lock permission", "Device Administrator", c.accent) {
            if (!isAdminActive()) requestAdmin()
        }
        val (notifRow, notifChip) = statusRow("🔔", "Notification", "Shows when detection is active", c.accent) {
            if (!hasNotif()) openSafe(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        checks.addView(camRow); checks.addV(divider(), 0, MATCH, 1)
        val (faceRow, faceChip) = statusRow("🙂", "Face verification", "Lock only for your face", c.accent) { showTab(1) }
        checks.addView(adminRow); checks.addV(divider(), 0, MATCH, 1)
        checks.addView(notifRow); checks.addV(divider(), 0, MATCH, 1)
        checks.addView(faceRow)
        page.addV(checks, 10)

        // Recent activity
        page.addV(sectionTitle("Recent activity"), 22)
        val recentCard = card(14)
        val recentBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        recentCard.addView(recentBox)
        page.addV(recentCard, 10)

        page.addV(tv("Background detection needs the ongoing notification. Android battery or camera restrictions may stop it.", 11f, c.sub, false, true, 1.15f), 20)

        val fmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

        homeRefresh = {
            val running = GestureCameraService.isRunning
            val now = System.currentTimeMillis()
            var start = prefs().getLong(K_START, 0L)
            if (running && start == 0L) { start = now; prefs().edit().putLong(K_START, now).apply() }
            if (!running && start != 0L && now - start > 8000) { start = 0L; prefs().edit().putLong(K_START, 0L).apply() }

            setChip(livePill, if (running) "● LIVE" else "● OFF", if (running) c.ok else c.sub)
            core.alpha = if (running) 1f else 0.55f
            core.background = if (running)
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c.accent, c.accentDeep)).apply { shape = GradientDrawable.OVAL }
            else oval(c.surface2, c.stroke, 1)
            if (running) startPulse(pulse) else stopPulse(pulse)

            heroTitle.text = if (running) "Protection is LIVE" else "Protection is OFF"
            heroTitle.setTextColor(if (running) c.accentFg else c.text)
            val flashActive = flashMsg != null && SystemClock.elapsedRealtime() < flashUntil
            val faceEnrolled = FaceEngine.hasEnrolled(this)
            val faceOn = prefs().getBoolean(K_FACE_ON, false)
            heroSub.text = when {
                flashActive -> flashMsg
                running && faceOn && faceEnrolled -> "Show an OK 👌 sign. Only your face can lock the phone"
                running -> "Show an OK 👌 sign to the front camera to lock your phone"
                else -> "Tap start and show an OK 👌 sign to lock your phone"
            }
            if (running && start > 0L) {
                val sec = ((now - start) / 1000).coerceAtLeast(0)
                setChip(uptime, String.format(Locale.US, "⏱  Live for %02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60), c.ok)
            } else setChip(uptime, "Not running", c.sub)

            if (running) {
                toggle.text = "STOP DETECTION"; toggle.setTextColor(c.text)
                toggle.background = withRipple(rounded(c.surface2, 16, c.stroke), 16, alpha(c.text, 40))
            } else {
                toggle.text = "START DETECTION"; toggle.setTextColor(c.onAccent)
                toggle.background = withRipple(accentGrad(16), 16, alpha(c.onAccent, 60))
            }

            val times = lockTimes()
            totalV.text = LockHistory.totalLocks(this).toString()
            val sod = startOfToday()
            todayV.text = times.count { it >= sod }.toString()
            lastV.text = times.firstOrNull()?.let { ago(it) } ?: "—"
            lastV.textSize = if (times.isEmpty()) 22f else 15f

            val holdMs = prefs().getLong("hold_ms", 800L).coerceIn(400L, 2000L)
            holdLabel.text = String.format(Locale.US, "Hold %.1f s", holdMs / 1000.0)

            val cam = hasCamera(); val adm = isAdminActive(); val nt = hasNotif()
            setChip(camChip, if (cam) "Granted ✓" else "Tap to grant", if (cam) c.ok else c.warn)
            setChip(adminChip, if (adm) "Enabled ✓" else "Tap to enable", if (adm) c.ok else c.warn)
            setChip(notifChip, if (nt) "Allowed ✓" else "Tap to allow", if (nt) c.ok else c.warn)
            setChip(faceChip,
                when { faceOn && faceEnrolled -> "On ✓"; faceOn -> "Set up"; else -> "Off" },
                when { faceOn && faceEnrolled -> c.ok; faceOn -> c.warn; else -> c.sub })

            recentBox.removeAllViews()
            if (times.isEmpty()) {
                recentBox.addView(tv("No locks yet. Show the OK 👌 sign to try it.", 13f, c.sub, false, true).apply { setPadding(0, dp(8), 0, dp(8)) })
            } else {
                times.take(5).forEachIndexed { i, t ->
                    val r = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                        setPadding(0, dp(9), 0, dp(9))
                    }
                    r.addView(iconBox("🔒", c.accent), LinearLayout.LayoutParams(dp(34), dp(34)))
                    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
                    col.addView(tv("Phone locked", 14f, c.text, true))
                    col.addView(tv(fmt.format(Date(t)), 11.5f, c.sub))
                    r.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
                    r.addView(tv(ago(t), 12f, c.accentFg, true))
                    if (i > 0) recentBox.addV(divider(), 0, MATCH, 1)
                    recentBox.addView(r)
                }
            }
        }
    }

    private fun startPulse(ring: View) {
        if (pulseAnim?.isRunning == true) return
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1800; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener {
                val t = it.animatedValue as Float
                val s = 1f + 0.44f * t
                ring.scaleX = s; ring.scaleY = s; ring.alpha = 0.6f * (1f - t)
            }
            start()
        }
    }

    private fun stopPulse(ring: View?) {
        pulseAnim?.cancel(); pulseAnim = null
        ring?.apply { alpha = 0f; scaleX = 1f; scaleY = 1f }
    }

    private fun requestAdmin() {
        openSafe(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allow Finger Sign Lock to lock this phone after an OK gesture.")
        })
    }

    private fun toggleDetection() {
        if (!hasCamera()) { cameraPermission.launch(Manifest.permission.CAMERA); return }
        if (GestureCameraService.isRunning) {
            stopService(Intent(this, GestureCameraService::class.java))
            prefs().edit().putLong(K_START, 0L).apply()
            flash("Gesture detection stopped.")
            handler.postDelayed({ refreshUi() }, 500)
            return
        }
        if (!isAdminActive()) {
            requestAdmin()
            flash("Enable Device Administrator, return here, then tap Start.")
            return
        }
        prefs().edit().putLong(K_START, System.currentTimeMillis()).apply()
        val intent = Intent(this, GestureCameraService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        flash("Starting gesture detection…")
        handler.postDelayed({ refreshUi() }, 700)
    }

    private fun toggleFaceLock() {
        if (prefs().getBoolean(K_FACE_ON, false)) {
            prefs().edit().putBoolean(K_FACE_ON, false).apply()
            toast("Face verification off"); rebuild(); return
        }
        if (!FaceEngine.hasEnrolled(this)) { startFaceFlow(false, true); return }
        prefs().edit().putBoolean(K_FACE_ON, true).apply()
        toast("Face verification on"); rebuild()
    }

    private fun resumeDetection() {
        if (!isAdminActive() || !hasCamera()) return
        prefs().edit().putLong(K_START, System.currentTimeMillis()).apply()
        val intent = Intent(this, GestureCameraService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
    }

    /** Camera can only be used by one component at a time, so detection is paused during face setup/test. */
    private fun startFaceFlow(test: Boolean, enableAfter: Boolean = false) {
        if (!hasCamera()) { cameraPermission.launch(Manifest.permission.CAMERA); return }
        val wasRunning = GestureCameraService.isRunning
        if (wasRunning) {
            stopService(Intent(this, GestureCameraService::class.java))
            prefs().edit().putLong(K_START, 0L).apply()
        }
        handler.postDelayed({
            val strict = prefs().getInt(K_FACE_STRICT, 1)
            FaceCaptureDialog(this, test, c.accent, FaceEngine.threshold(strict)) { saved ->
                if (saved) {
                    if (enableAfter) prefs().edit().putBoolean(K_FACE_ON, true).apply()
                    toast("Face saved")
                }
                if (wasRunning) handler.postDelayed({ resumeDetection() }, 700)
                rebuild()
            }.show()
        }, if (wasRunning) 700L else 0L)
    }

    // ═════════════════════════ SETTINGS ═════════════════════════
    private fun segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(4), dp(4), dp(4))
            background = rounded(c.surface2, 16, c.stroke)
        }
        options.forEachIndexed { i, o ->
            val sel = i == selected
            val t = tv(o, 13.5f, if (sel) c.onAccent else c.sub, true, true).apply {
                setPadding(0, dp(11), 0, dp(11))
                if (sel) background = accentGrad(12)
                isClickable = true
                setOnClickListener { onSelect(i) }
            }
            row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return row
    }

    private fun sliderBlock(title: String, hint: String, max: Int, progress: Int, valueText: (Int) -> String, onChange: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv(title, 14.5f, c.text, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val value = chip(valueText(progress), c.accentFg)
        head.addView(value)
        box.addView(head)
        box.addV(tv(hint, 12f, c.sub, spacing = 1.15f), 3)
        val seek = SeekBar(this).apply {
            this.max = max; this.progress = progress
            progressTintList = ColorStateList.valueOf(c.accent)
            thumbTintList = ColorStateList.valueOf(c.accent)
            progressBackgroundTintList = ColorStateList.valueOf(c.stroke)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    setChip(value, valueText(p), c.accentFg)
                    if (fromUser) onChange(p)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        box.addV(seek, 6)
        return box
    }

    private fun buildSettings(page: LinearLayout) {
        screenTitle(page, "Settings", "Make the app work your way")

        // Appearance
        page.addV(sectionTitle("Appearance"), 22)
        val look = card()
        look.addView(tv("Theme", 14.5f, c.text, true))
        look.addV(segmented(listOf("🌙  Dark", "☀️  Light", "📱  System"), prefs().getInt(K_MODE, 0).coerceIn(0, 2)) {
            prefs().edit().putInt(K_MODE, it).apply(); rebuild()
        }, 10)
        look.addV(tv("Accent color", 14.5f, c.text, true), 20)
        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val selAccent = prefs().getInt(K_ACCENT, 0).coerceIn(0, 2)
        accents.forEachIndexed { i, a ->
            val sel = i == selAccent
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; isClickable = true
                setOnClickListener { prefs().edit().putInt(K_ACCENT, i).apply(); rebuild() }
            }
            val holder = FrameLayout(this)
            val ring = View(this).apply { background = oval(Color.TRANSPARENT, if (sel) c.text else Color.TRANSPARENT, 2) }
            val dot = View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a.main, a.deep)).apply { shape = GradientDrawable.OVAL }
            }
            holder.addView(ring, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER))
            holder.addView(dot, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
            if (sel) holder.addView(tv("✓", 18f, a.onAccent, true, true), FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
            col.addView(holder, LinearLayout.LayoutParams(dp(58), dp(58)))
            col.addView(tv(a.name, 12.5f, if (sel) c.text else c.sub, sel), LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(5) })
            swatches.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        look.addV(swatches, 12)
        page.addV(look, 10)

        // Detection
        page.addV(sectionTitle("Gesture detection"), 22)
        val det = card()
        val sensNames = listOf("Low", "Medium", "High")
        det.addView(sliderBlock(
            "Sensitivity", "Low is stricter (fewer accidental locks). High detects the sign more easily.",
            2, prefs().getInt("sensitivity", 1).coerceIn(0, 2), { sensNames[it] }
        ) { prefs().edit().putInt("sensitivity", it).apply() })
        det.addV(divider(), 14, MATCH, 1)
        det.addV(sliderBlock(
            "Hold time", "How long you keep the sign steady before the phone locks.",
            8, ((prefs().getLong("hold_ms", 800L) - 400L) / 200L).toInt().coerceIn(0, 8),
            { String.format(Locale.US, "%.1f s", (400 + it * 200) / 1000.0) }
        ) { prefs().edit().putLong("hold_ms", 400L + it * 200L).apply() }, 14)
        det.addV(divider(), 14, MATCH, 1)
        det.addV(sliderBlock(
            "Lock cooldown", "Minimum gap between two automatic locks.",
            5, ((prefs().getInt("cooldown_sec", 5) - 5) / 5).coerceIn(0, 5),
            { "${5 + it * 5} s" }
        ) { prefs().edit().putInt("cooldown_sec", 5 + it * 5).apply() }, 14)
        det.addV(tv("✨ Changes apply instantly, even while detection is running.", 12f, c.sub, false, false, 1.15f), 14)
        page.addV(det, 10)

        // Face verification
        page.addV(sectionTitle("Face verification"), 22)
        val face = card()
        val enrolled = FaceEngine.hasEnrolled(this)
        val faceOnNow = prefs().getBoolean(K_FACE_ON, false) && enrolled
        val swRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isClickable = true
            setOnClickListener { toggleFaceLock() }
        }
        val swCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        swCol.addView(tv("Lock only for my face", 15f, c.text, true))
        swCol.addV(tv("The OK sign locks the phone only if your saved face matches. Otherwise you just get a \"Face not recognised\" notification.", 12f, c.sub, spacing = 1.15f), 2)
        swRow.addView(swCol, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(12) })
        val swStates = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        val faceSwitch = SwitchCompat(this).apply {
            isChecked = faceOnNow; isClickable = false
            thumbTintList = ColorStateList(swStates, intArrayOf(c.accent, c.sub))
            trackTintList = ColorStateList(swStates, intArrayOf(alpha(c.accent, 110), alpha(c.sub, 80)))
        }
        swRow.addView(faceSwitch)
        face.addView(swRow)
        face.addV(divider(), 14, MATCH, 1)
        val faceStatus = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        faceStatus.addView(iconBox("🙂", if (enrolled) c.ok else c.warn), LinearLayout.LayoutParams(dp(40), dp(40)))
        val fsCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        fsCol.addView(tv(if (enrolled) "Face saved ✓" else "No face saved yet", 14.5f, c.text, true))
        fsCol.addView(tv(if (enrolled) "Stored on this phone as measurements, not a photo" else "Save your face once to use this feature", 12f, c.sub))
        faceStatus.addView(fsCol, LinearLayout.LayoutParams(0, WRAP, 1f))
        face.addV(faceStatus, 14)
        face.addV(primaryButton(if (enrolled) "Re-enroll my face" else "Set up my face") { startFaceFlow(false, false) }, 14)
        if (enrolled) {
            face.addV(secondaryButton("🧪  Test face match") { startFaceFlow(true) }, 10)
            face.addV(secondaryButton("🗑  Delete face data", c.bad) {
                confirm("Delete face data?", "Your saved face measurements will be removed and Face verification will turn off.", "Delete", true) {
                    FaceEngine.clear(this); toast("Face data deleted"); rebuild()
                }
            }, 10)
        }
        face.addV(tv("Match strictness", 14.5f, c.text, true), 18)
        face.addV(segmented(listOf("Strict", "Balanced", "Relaxed"), prefs().getInt(K_FACE_STRICT, 1).coerceIn(0, 2)) {
            prefs().edit().putInt(K_FACE_STRICT, it).apply(); rebuild()
        }, 10)
        face.addV(tv("Not matching you? Use Test face match to see your score, then choose Relaxed. Too easy for others? Choose Strict and re-enroll.", 12f, c.sub, spacing = 1.15f), 10)
        face.addV(tv("⚠ This is a convenience filter, not secure biometric authentication. A photo or a very similar face may pass.", 12f, c.warn, spacing = 1.15f), 10)
        page.addV(face, 10)

        // Permissions & system
        page.addV(sectionTitle("Permissions & system"), 22)
        val perms = card(12)
        perms.addView(actionRow("📷", "Camera permission", if (hasCamera()) "Granted" else "Not granted. Tap to allow", if (hasCamera()) c.ok else c.warn) {
            if (hasCamera()) openAppDetails() else cameraPermission.launch(Manifest.permission.CAMERA)
        })
        perms.addV(divider(), 0, MATCH, 1)
        val adm = isAdminActive()
        perms.addView(actionRow("🔐", if (adm) "Disable lock permission" else "Enable lock permission",
            if (adm) "Required before you can uninstall the app" else "Device Administrator is off. Tap to enable",
            if (adm) c.accent else c.warn) {
            if (adm) confirm("Disable lock permission?", "Detection will stop and the app will no longer be able to lock your phone. Use this before uninstalling.", "Disable", true) {
                stopService(Intent(this, GestureCameraService::class.java))
                prefs().edit().putLong(K_START, 0L).apply()
                try { dpm().removeActiveAdmin(adminComponent()) } catch (_: Exception) {}
                toast("Lock permission disabled"); rebuild()
            } else requestAdmin()
        })
        perms.addV(divider(), 0, MATCH, 1)
        perms.addView(actionRow("🔔", "Notifications", if (hasNotif()) "Allowed" else "Blocked. Tap to open settings", if (hasNotif()) c.ok else c.warn) {
            openSafe(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        })
        perms.addV(divider(), 0, MATCH, 1)
        perms.addView(actionRow("🔋", "Battery optimization", "Set to unrestricted so Android doesn't stop detection", c.accent) {
            openSafe(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        perms.addV(divider(), 0, MATCH, 1)
        perms.addView(actionRow("⚙️", "App info", "Open Android's settings page for this app", c.accent) { openAppDetails() })
        page.addV(perms, 10)

        // Data
        page.addV(sectionTitle("Data & reset"), 22)
        val data = card()
        data.addView(tv("Lock history stores only counts and timestamps, locally on this phone.", 12.5f, c.sub, spacing = 1.15f))
        data.addV(secondaryButton("🗑  Clear lock history") {
            confirm("Clear lock history?", "This removes your total lock count and all saved timestamps.", "Clear", true) {
                LockHistory.clear(this); toast("History cleared"); refreshUi()
            }
        }, 12)
        data.addV(secondaryButton("↺  Reset all settings", c.bad) {
            confirm("Reset all settings?", "Sensitivity, hold time, cooldown, face verification switch, theme and accent color go back to defaults. Saved face data is kept.", "Reset", true) {
                prefs().edit().remove("sensitivity").remove("hold_ms").remove("cooldown_sec").remove(K_MODE).remove(K_ACCENT).remove(K_FACE_ON).remove(K_FACE_STRICT).apply()
                toast("Settings reset"); rebuild()
            }
        }, 10)
        page.addV(data, 10)
    }

    private fun openAppDetails() {
        openSafe(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    // ═════════════════════════ INFO ═════════════════════════
    private fun accordion(emoji: String, title: String, tint: Int, build: (LinearLayout) -> Unit): LinearLayout {
        val box = card(0)
        val open = openSections.contains(title)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14)); isClickable = true; isFocusable = true
            background = withRipple(ColorDrawable(Color.TRANSPARENT), 22, alpha(c.accent, 50))
        }
        head.addView(iconBox(emoji, tint), LinearLayout.LayoutParams(dp(40), dp(40)))
        head.addView(tv(title, 15.5f, c.text, true).apply { setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, WRAP, 1f))
        val chevron = tv(if (open) "▲" else "▼", 12f, c.sub)
        head.addView(chevron)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(16))
            visibility = if (open) View.VISIBLE else View.GONE
        }
        body.addV(divider(), 0, MATCH, 1)
        build(body)
        head.setOnClickListener {
            val nowOpen = body.visibility != View.VISIBLE
            body.visibility = if (nowOpen) View.VISIBLE else View.GONE
            chevron.text = if (nowOpen) "▲" else "▼"
            if (nowOpen) openSections.add(title) else openSections.remove(title)
        }
        box.addView(head); box.addView(body)
        return box
    }

    private fun lines(parent: LinearLayout, items: List<String>, markerColor: Int, marker: (Int) -> String) {
        items.forEachIndexed { i, s ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(tv(marker(i), 13.5f, markerColor, true).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }, LinearLayout.LayoutParams(dp(26), WRAP))
            row.addView(tv(s, 13.5f, c.text, spacing = 1.2f), LinearLayout.LayoutParams(0, WRAP, 1f))
            parent.addV(row, if (i == 0) 12 else 9)
        }
    }

    private fun contactRow(parent: LinearLayout, emoji: String, title: String, sub: String, onClick: () -> Unit) {
        parent.addV(divider(), 6, MATCH, 1)
        parent.addView(actionRow(emoji, title, sub, c.accent, "↗", onClick))
    }

    private fun buildInfo(page: LinearLayout) {
        screenTitle(page, "Info", "About, guide, safety and policies")

        // App card
        val app = card(20).apply { gravity = Gravity.CENTER_HORIZONTAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.finger_sign_logo); scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.BLACK, 22, c.accent, 2); clipToOutline = true
        }
        app.addView(logo, LinearLayout.LayoutParams(dp(84), dp(84)))
        app.addV(tv("Finger Sign Lock", 21f, c.text, true, true), 12)
        app.addV(tv("Version ${versionName()}", 12.5f, c.sub, false, true), 2)
        app.addV(tv("Show an OK 👌 sign and your phone locks instantly. Fast, private, on-device.", 13.5f, c.sub, false, true, 1.2f), 10)
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        chips.addView(chip("On-device", c.ok)); chips.addView(chip("No internet", c.accentFg), LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        app.addV(chips, 14)
        page.addV(app, 18)

        // Developer
        page.addV(sectionTitle("Developer"), 22)
        val dev = card(18)
        val devHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val avatar = tv(Dev.NAME.take(1).uppercase(), 24f, c.onAccent, true, true).apply { background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c.accent, c.accentDeep)).apply { shape = GradientDrawable.OVAL } }
        devHead.addView(avatar, LinearLayout.LayoutParams(dp(56), dp(56)))
        val devCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        devCol.addView(tv(Dev.NAME, 18f, c.text, true)); devCol.addView(tv(Dev.ROLE, 12.5f, c.accentFg, true))
        devHead.addView(devCol, LinearLayout.LayoutParams(0, WRAP, 1f))
        dev.addView(devHead)
        dev.addV(tv(Dev.ABOUT, 13.5f, c.sub, spacing = 1.2f), 12)
        if (Dev.EMAIL.isNotBlank()) contactRow(dev, "✉️", "Email / feedback", Dev.EMAIL) {
            openSafe(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${Dev.EMAIL}")).putExtra(Intent.EXTRA_SUBJECT, "Finger Sign Lock feedback"))
        }
        if (Dev.GITHUB.isNotBlank()) contactRow(dev, "💻", "GitHub", Dev.GITHUB) { openSafe(Intent(Intent.ACTION_VIEW, Uri.parse(Dev.GITHUB))) }
        if (Dev.WEBSITE.isNotBlank()) contactRow(dev, "🌐", "Website", Dev.WEBSITE) { openSafe(Intent(Intent.ACTION_VIEW, Uri.parse(Dev.WEBSITE))) }
        page.addV(dev, 10)

        // Guides & policies
        page.addV(sectionTitle("Guide & policies"), 22)

        page.addV(accordion("📖", "How to use", c.accent) { b ->
            lines(b, listOf(
                "Open the app and allow the Camera permission when asked.",
                "Allow Notifications so the \"active\" notification stays visible.",
                "On Home, tap Start Detection. The first time, enable Device Administrator. This is the only way Android lets an app lock the screen.",
                "Come back and tap Start Detection again. The status turns LIVE.",
                "Show a clear OK 👌 sign to the front camera with either hand: thumb and index finger touching, other three fingers open.",
                "Hold it steady for the hold time (0.8 s by default). Your phone locks.",
                "Optional: in Settings ▸ Face verification, save your face once and switch it on. Then only you can lock the phone with the OK sign. For anyone else you just get a \"Face not recognised\" notification."
            ), c.accentFg) { "${it + 1}." }
            b.addV(tv("TIPS FOR BEST RESULTS", 11f, c.accentFg, true).apply { letterSpacing = 0.08f }, 18)
            lines(b, listOf(
                "Use good lighting and keep your whole hand inside the camera view.",
                "Keep the front camera uncovered (no cover, sticker or dirty lens).",
                "Not detecting? Raise Sensitivity or shorten Hold time in Settings.",
                "Locking by mistake? Lower Sensitivity or increase Hold time.",
                "Minimise the app after starting. Don't swipe it away or force-stop it."
            ), c.accentFg) { "•" }
        }, 10)

        page.addV(accordion("⚠️", "Warnings", c.warn) { b ->
            lines(b, listOf(
                "Detection uses the front camera continuously while it is ON. This uses battery, and Android may show a camera indicator. Turn it off when you don't need it.",
                "Force-stopping or swiping away the app stops detection. Some brands (Xiaomi, Oppo, Vivo, Realme, Samsung and others) aggressively kill background apps. Set battery to unrestricted for this app.",
                "Depending on your Android version and phone brand, camera access in the background or with the screen off may be restricted. Detection cannot be guaranteed in every situation.",
                "Accidental locks can happen if you make a similar hand sign. Adjust Sensitivity and Hold time to suit you.",
                "Device Administrator must be disabled before you can uninstall the app. Use Settings ▸ Disable lock permission.",
                "This app only locks the screen. It is not a security feature and does not protect your data. Keep your PIN, pattern or biometric lock enabled.",
                "Face verification is a convenience filter, not secure biometric authentication. A photo or a very similar looking person may pass. Do not rely on it to protect your phone.",
                "With Face verification on, your face must be visible to the front camera together with the OK sign. Face setup and test pause detection for a moment because they share the camera.",
                "Gesture recognition is approximate. Lighting, hand angle, camera quality and phone performance affect accuracy."
            ), c.warn) { "⚠" }
        }, 10)

        page.addV(accordion("🔒", "Privacy policy", c.ok) { b ->
            lines(b, listOf(
                "Camera frames are analysed on your phone by an on-device hand-landmark model. They are never saved, recorded or uploaded.",
                "The app has no Internet permission, so it cannot send data off your device.",
                "Face verification saves face-shape measurements (numbers), not photos, in the app's private storage on this phone. Delete them any time in Settings ▸ Face verification.",
                "Only your lock count, lock timestamps and your settings are stored, locally on this phone. Clear them any time from Settings, or by uninstalling.",
                "Camera: to see your hand. Notifications: to show that detection is active. Foreground service: to keep detection running. Device Administrator: only to lock the screen. The app cannot read your password, wipe data or change other device policies.",
                "No account, ads or analytics are built into this app."
            ), c.ok) { "✓" }
        }, 10)

        page.addV(accordion("📜", "Terms & Conditions", c.accent) { b ->
            lines(b, listOf(
                "Acceptance: by installing or using Finger Sign Lock you agree to these terms.",
                "Personal use: the app is provided for personal use on devices you own or are allowed to use.",
                "No warranty: the app is provided \"as is\", without warranties of any kind. Uninterrupted operation and detection accuracy are not guaranteed.",
                "Your responsibility: you are responsible for the permissions you grant and for keeping your device secured with a screen lock.",
                "Limitation of liability: the developer is not liable for any loss or damage arising from use of the app, including missed or accidental locks, battery drain, data loss or device issues.",
                "Acceptable use: do not use the app to monitor or record other people, or on devices you do not have permission to use.",
                "Changes: features and these terms may change in future versions.",
                "Contact: ${Dev.NAME} (developer)."
            ), c.accentFg) { "${it + 1}." }
        }, 10)

        page.addV(accordion("❓", "FAQ & troubleshooting", c.accent) { b ->
            val faq = listOf(
                "Detection won't start" to "Open Home ▸ Ready check and make sure Camera, Lock permission and Notification all show a green tick.",
                "Phone doesn't lock on the OK sign" to "Check that the status says LIVE, improve the lighting, keep your hand fully in view, then raise Sensitivity or shorten Hold time.",
                "It stops working after a while" to "Your phone's battery saver is likely stopping it. Open Settings ▸ Battery optimization and set this app to unrestricted.",
                "I can't uninstall the app" to "Go to Settings ▸ Disable lock permission, then uninstall normally.",
                "\"Face not recognised\" keeps appearing" to "Face the camera in good light while showing the OK sign. Use Settings ▸ Test face match to see your score, then pick Relaxed strictness or re-enroll your face in good lighting.",
                "Face check lets other people in" to "Set Match strictness to Strict and re-enroll your face. Remember it is not secure authentication.",
                "Does it work with my left hand?" to "Yes. Either hand works."
            )
            faq.forEachIndexed { i, (q, a) ->
                b.addV(tv(q, 14f, c.text, true), if (i == 0) 12 else 14)
                b.addV(tv(a, 13f, c.sub, spacing = 1.2f), 3)
            }
        }, 10)

        page.addV(tv("Made with ❤ by ${Dev.NAME}", 12.5f, c.sub, false, true), 24)
        page.addV(tv("Finger Sign Lock v${versionName()}", 11f, c.sub, false, true), 2)
    }
}
