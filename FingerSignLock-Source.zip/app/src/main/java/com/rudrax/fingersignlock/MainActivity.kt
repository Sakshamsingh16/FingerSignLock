package com.rudrax.fingersignlock

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var statusDot: TextView
    private lateinit var toggleButton: Button
    private lateinit var cameraState: TextView
    private lateinit var adminState: TextView
    private lateinit var totalLocksText: TextView
    private lateinit var historyList: TextView
    private lateinit var sensitivityValue: TextView
    private lateinit var holdValue: TextView
    private lateinit var cooldownValue: TextView
    private lateinit var notificationPermissionLauncher: androidx.activity.result.ActivityResultLauncher<String>

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        refreshUi(if (granted) "Camera permission granted." else "Camera permission is required for gesture detection.")
        if (granted) requestNotificationPermissionIfNeeded()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 7, 13)
        window.navigationBarColor = Color.rgb(15, 7, 13)
        notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA)
        } else {
            requestNotificationPermissionIfNeeded()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("fsl_settings", Context.MODE_PRIVATE)

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun redGradient(radius: Int = 18) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.rgb(255, 48, 74), Color.rgb(186, 20, 58), Color.rgb(83, 13, 37))
    ).apply { cornerRadius = dp(radius).toFloat() }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = rounded(Color.rgb(31, 20, 31), 20, Color.rgb(90, 43, 60))
    }

    private fun gap(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(15, 7, 13)); isFillViewport = true }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(24)) }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.finger_sign_logo); scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.BLACK, 16, Color.rgb(255, 57, 86)); clipToOutline = true
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(58), dp(58)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titleBox.addView(label("FINGER SIGN LOCK", 19f, Color.WHITE, true))
        titleBox.addView(label("CYBER RED  •  SMART SECURITY", 10f, Color.rgb(255, 100, 126), true))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("v1.1", 12f, Color.LTGRAY))
        page.addView(header); page.addView(gap(18))

        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(18), dp(22), dp(18), dp(22)); background = redGradient(24) }
        hero.addView(label("Your hand. Your lock.", 23f, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        hero.addView(gap(7))
        hero.addView(label("Show an OK 👌 sign with either hand", 14f, Color.WHITE).apply { gravity = Gravity.CENTER })
        hero.addView(gap(8))
        hero.addView(label("PRIVATE • ON-DEVICE PROCESSING", 10f, Color.rgb(255, 224, 230), true).apply { gravity = Gravity.CENTER })
        page.addView(hero); page.addView(gap(15))

        val statusCard = card()
        val statusRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        statusDot = label("●", 20f, Color.rgb(255, 175, 75), true)
        val stateBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        stateBox.addView(label("Gesture detection", 17f, Color.WHITE, true))
        status = label("Checking status…", 12f, Color.rgb(210, 190, 203)); stateBox.addView(status)
        statusRow.addView(statusDot); statusRow.addView(stateBox, LinearLayout.LayoutParams(0, -2, 1f))
        statusCard.addView(statusRow); statusCard.addView(gap(13))
        toggleButton = Button(this).apply {
            text = "START DETECTION"; isAllCaps = false; textSize = 15f; setTextColor(Color.WHITE); background = redGradient()
            setOnClickListener { toggleDetection() }
        }
        statusCard.addView(toggleButton); page.addView(statusCard); page.addView(gap(15))

        page.addView(label("ACTIVITY DASHBOARD", 12f, Color.rgb(255, 105, 133), true)); page.addView(gap(8))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val statCard = card()
        statCard.addView(label("TOTAL PHONE LOCKS", 10f, Color.rgb(220, 175, 193), true))
        totalLocksText = label("0", 30f, Color.WHITE, true); statCard.addView(totalLocksText)
        statCard.addView(label("Stored on this device", 11f, Color.LTGRAY))
        stats.addView(statCard, LinearLayout.LayoutParams(0, -2, 1f)); page.addView(stats); page.addView(gap(15))

        page.addView(label("SMART GESTURE SETTINGS", 12f, Color.rgb(255, 105, 133), true)); page.addView(gap(8))
        val settings = card()
        settings.addView(label("Sensitivity", 15f, Color.WHITE, true))
        sensitivityValue = label("Medium", 12f, Color.rgb(255, 175, 190)); settings.addView(sensitivityValue)
        val sensitivity = SeekBar(this).apply { max = 2; progress = prefs().getInt("sensitivity", 1) }
        sensitivity.setOnSeekBarChangeListener(seekListener { progress ->
            prefs().edit().putInt("sensitivity", progress).apply()
            sensitivityValue.text = listOf("Low (stricter)", "Medium", "High (more responsive)")[progress]
        })
        settings.addView(sensitivity); settings.addView(gap(10))

        settings.addView(label("Hold gesture before locking", 15f, Color.WHITE, true))
        holdValue = label("0.8 seconds", 12f, Color.rgb(255, 175, 190)); settings.addView(holdValue)
        val hold = SeekBar(this).apply { max = 8; progress = ((prefs().getLong("hold_ms", 800L) - 400L) / 200L).toInt().coerceIn(0, 8) }
        hold.setOnSeekBarChangeListener(seekListener { progress ->
            val ms = 400L + progress * 200L; prefs().edit().putLong("hold_ms", ms).apply(); holdValue.text = "${ms / 1000.0} seconds"
        })
        settings.addView(hold); settings.addView(gap(10))

        settings.addView(label("Lock cooldown", 15f, Color.WHITE, true))
        cooldownValue = label("5 seconds", 12f, Color.rgb(255, 175, 190)); settings.addView(cooldownValue)
        val cooldown = SeekBar(this).apply { max = 5; progress = ((prefs().getInt("cooldown_sec", 5) - 5) / 5).coerceIn(0, 5) }
        cooldown.setOnSeekBarChangeListener(seekListener { progress ->
            val seconds = 5 + progress * 5; prefs().edit().putInt("cooldown_sec", seconds).apply(); cooldownValue.text = "$seconds seconds"
        })
        settings.addView(cooldown); page.addView(settings); page.addView(gap(15))

        page.addView(label("PRIVACY MODE", 12f, Color.rgb(255, 105, 133), true)); page.addView(gap(8))
        val privacy = card()
        privacy.addView(label("🛡  On-device processing is enabled", 15f, Color.WHITE, true))
        privacy.addView(gap(5))
        privacy.addView(label("Camera frames are analysed on your phone and are not saved or uploaded. Lock history stores only timestamps and counts locally.", 12f, Color.rgb(214, 195, 207)))
        page.addView(privacy); page.addView(gap(15))

        page.addView(label("RECENT LOCK HISTORY", 12f, Color.rgb(255, 105, 133), true)); page.addView(gap(8))
        val history = card()
        historyList = label("No locks recorded yet.", 13f, Color.WHITE)
        history.addView(historyList); history.addView(gap(8))
        val clear = Button(this).apply {
            text = "Clear local history"; isAllCaps = false; setTextColor(Color.WHITE); background = rounded(Color.rgb(78, 34, 53), 14, Color.rgb(120, 52, 75))
            setOnClickListener { LockHistory.clear(this@MainActivity); refreshUi("Local lock history cleared.") }
        }
        history.addView(clear); page.addView(history); page.addView(gap(15))

        page.addView(label("READY CHECK", 12f, Color.rgb(255, 105, 133), true)); page.addView(gap(8))
        val checks = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cam = miniStatusCard("📷", "Camera", "Checking")
        cameraState = cam.second
        val admin = miniStatusCard("🔐", "Lock permission", "Checking")
        adminState = admin.second
        checks.addView(cam.first, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        checks.addView(admin.first, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        page.addView(checks); page.addView(gap(18))
        page.addView(label("Background detection needs the ongoing notification. Android battery or camera restrictions may stop it.", 11f, Color.rgb(170, 151, 165)).apply { gravity = Gravity.CENTER })
        scroll.addView(page); setContentView(scroll)
        refreshUi()
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { onChange(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun miniStatusCard(emoji: String, title: String, initial: String): Pair<LinearLayout, TextView> {
        val c = card(); c.addView(label(emoji, 22f, Color.WHITE)); c.addView(gap(5)); c.addView(label(title, 13f, Color.WHITE, true))
        val v = label(initial, 11f, Color.rgb(255, 180, 192)); c.addView(v); return c to v
    }

    private fun adminComponent() = ComponentName(this, LockAdminReceiver::class.java)
    private fun isAdminActive(): Boolean = (getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(adminComponent())

    private fun toggleDetection() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA); return
        }
        if (GestureCameraService.isRunning) {
            stopService(Intent(this, GestureCameraService::class.java)); refreshUi("Gesture detection stopped."); return
        }
        if (!isAdminActive()) {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allow Finger Sign Lock to lock this phone after an OK gesture.")
            })
            refreshUi("Enable Device Administrator, return here, then tap Start."); return
        }
        val intent = Intent(this, GestureCameraService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        refreshUi("Starting gesture detection…")
    }

    private fun refreshUi(message: String? = null) {
        if (!::status.isInitialized) return
        val running = GestureCameraService.isRunning
        status.text = message ?: if (running) "Active — show OK sign to lock" else "Off — tap Start Detection"
        statusDot.setTextColor(if (running) Color.rgb(72, 235, 146) else Color.rgb(255, 175, 75))
        toggleButton.text = if (running) "STOP GESTURE DETECTION" else "START GESTURE DETECTION"
        totalLocksText.text = LockHistory.totalLocks(this).toString()
        val events = LockHistory.recentLocks(this, 8)
        historyList.text = if (events.isEmpty()) "No locks recorded yet." else events.mapIndexed { i, time -> "${i + 1}.  $time" }.joinToString("\n")
        cameraState.text = if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) "Granted ✓" else "Needed"
        adminState.text = if (isAdminActive()) "Enabled ✓" else "Needed"
        cameraState.setTextColor(if (cameraState.text.contains("✓")) Color.rgb(92, 232, 153) else Color.rgb(255, 175, 75))
        adminState.setTextColor(if (adminState.text.contains("✓")) Color.rgb(92, 232, 153) else Color.rgb(255, 175, 75))
        sensitivityValue.text = listOf("Low (stricter)", "Medium", "High (more responsive)")[prefs().getInt("sensitivity", 1).coerceIn(0, 2)]
        val holdMs = prefs().getLong("hold_ms", 800L); holdValue.text = "${holdMs / 1000.0} seconds"
        cooldownValue.text = "${prefs().getInt("cooldown_sec", 5)} seconds"
    }
}
