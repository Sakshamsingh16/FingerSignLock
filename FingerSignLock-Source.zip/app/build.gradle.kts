plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rudrax.fingersignlock"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rudrax.fingersignlock"
        minSdk = 24
        targetSdk = 35
        versionCode = 4
        versionName = "1.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.camera:camera-camera2:1.4.2")
    implementation("androidx.camera:camera-lifecycle:1.4.2")
    implementation("androidx.camera:camera-view:1.4.2")
    implementation("com.google.mediapipe:tasks-vision:0.10.21")
}

// Downloads the MediaPipe face model into assets on first build (used by the face-verification feature).
val downloadFaceModel by tasks.registering {
    val out = layout.projectDirectory.file("src/main/assets/face_landmarker.task").asFile
    outputs.file(out)
    doLast {
        if (!out.exists() || out.length() == 0L) {
            out.parentFile.mkdirs()
            val url = java.net.URI(
                "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
            ).toURL()
            url.openStream().use { input -> out.outputStream().use { output -> input.copyTo(output) } }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadFaceModel) }
