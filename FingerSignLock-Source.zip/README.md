# FingerSignLock 1.1 — Cyber Red

Android Kotlin app that uses the front camera and MediaPipe Hand Landmarker to detect an OK 👌 gesture with either hand and lock the phone through Android Device Administrator.

## Features in this source update
- Cyber Red dashboard UI and launcher logo.
- Smart settings: sensitivity (Low/Medium/High), gesture hold duration (0.4–2.0 seconds), and lock cooldown (5–30 seconds).
- Background detection through a camera foreground service with an ongoing notification. Start detection while the app is visible, then minimize it; do not force-stop the app. Android may still restrict camera service restarts or background use.
- Activity dashboard with total locks and the latest eight local lock timestamps.
- Privacy-first processing: camera frames are processed on-device and are not saved or uploaded. Only lock counts and timestamps are stored locally.
- Clear local lock history button.
- Left/right hand support retained.

## Build with GitHub Actions
1. Upload this ZIP to the repository root as `FingerSignLock-Source.zip` (replace the previous ZIP).
2. Ensure `.github/workflows/android.yml` is present in the repository outside the ZIP, or trigger the existing workflow manually.
3. The workflow extracts this ZIP, downloads the MediaPipe hand model, and runs `gradle --no-daemon assembleDebug` using Java 17 and Gradle 8.9.
4. If successful, download the `FingerSignLock-debug-apk` artifact from the Actions run.

## First run
1. Install the APK and open the app.
2. Grant camera permission and allow notifications so the active-service notification is visible.
3. Enable Device Administrator when prompted.
4. Tap Start Detection. Keep the camera uncovered and the ongoing notification visible.
5. Show a clear OK 👌 sign with either hand for the configured hold duration.

## Limitations
- This source has not been built or device-tested in this environment. GitHub Actions must confirm compilation before using the APK.
- Gesture recognition is heuristic; lighting, hand angle, camera quality and device performance can affect accuracy.
- Background camera behavior is subject to Android version, vendor power management, permissions, and foreground-service restrictions.
- This is a debug APK, not a Play Store release build.
