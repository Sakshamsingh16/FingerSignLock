# FingerSignLock

A Kotlin Android prototype that uses CameraX and MediaPipe Hand Landmarker to detect an OK hand sign and lock the phone.

## Build on GitHub
1. Upload these source files into your `Sakshamsingh16/FingerSignLock` repository, preserving folder paths.
2. Commit to the `main` branch.
3. Open **Actions → Android APK Build**.
4. Open the successful workflow run and download `FingerSignLock-debug-apk`.
5. Extract the downloaded ZIP to get `app-debug.apk`.

## Use
- Install the APK and open Finger Sign Lock.
- Grant camera permission.
- Tap Start gesture detection and enable Device Administrator when Android asks.
- Tap Start again. Keep the app open and the front camera pointed at your hand.
- The app locks after detecting the OK sign in several consecutive frames.

## Limitations
This prototype detects gestures only while its app screen is active. It does not run a persistent camera watcher in other apps or while the display is off. Gesture detection is heuristic and can vary with lighting, angle, and hand shape. The generated APK is a debug build.
