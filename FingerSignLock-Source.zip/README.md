# FingerSignLock

Android Kotlin app using CameraX and MediaPipe Hand Landmarker to detect an OK 👌 hand sign and lock the phone.

## Build on GitHub
1. Upload the source files preserving the folder structure, or use the supplied source ZIP with the GitHub Actions workflow.
2. Ensure the workflow downloads `hand_landmarker.task` into `app/src/main/assets/hand_landmarker.task` before building.
3. Open Actions, wait for a successful run, then download the `FingerSignLock-debug-apk` artifact.

## Use
1. Install the APK and open Finger Sign Lock.
2. Grant Camera permission.
3. Tap Start and enable Device Administrator when Android asks.
4. Return to the app and tap Start again.
5. The ongoing notification means background gesture detection is active. You may minimize the app while leaving the service running.

## Notes
- The camera must remain available and uncovered. Android/device battery settings may stop background work; allow background activity for the app if needed.
- Detection can work with either hand, but hand angle, lighting, and camera orientation can affect heuristic gesture recognition.
- To stop background detection, reopen the app and tap Stop or stop the foreground service from Android settings.
- This is a debug build. It cannot detect gestures after the service is stopped or when the OS revokes camera access.
